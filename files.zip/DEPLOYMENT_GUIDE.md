# 🚀 GitHub Pages Deployment Guide

## Step-by-Step Instructions to Deploy Your Enrollment Form

### Before You Start
- You'll need a GitHub account (create one free at https://github.com/signup)
- You have 5 files ready to upload

---

## Method 1: Web Upload (No Technical Knowledge Needed) ⭐ RECOMMENDED

### Step 1: Create a New Repository

1. Go to **https://github.com** and log in
2. Click the **green "New"** button (or go to https://github.com/new)
3. Fill in the details:
   ```
   Repository name: enrollment-form
   Description: Waystar Enrollment Consultation Request Form
   ✓ Public (must be public for free GitHub Pages)
   ✗ Don't check "Add a README file"
   ```
4. Click **"Create repository"**

### Step 2: Upload Your Files

1. You'll see a page with setup instructions
2. Look for the text: **"uploading an existing file"** (it's a link)
3. Click that link
4. **Drag and drop all 5 files** from the `enrollment-form` folder:
   - index.html
   - styles.css
   - script.js
   - README.md
   - .gitignore
5. Scroll down and click **"Commit changes"**

### Step 3: Enable GitHub Pages

1. Click on **"Settings"** tab (top of your repository)
2. Scroll down the left sidebar and click **"Pages"**
3. Under "Source":
   - Branch: Select **"main"** (or "master")
   - Folder: Keep as **"/ (root)"**
4. Click **"Save"**
5. Wait 1-2 minutes for deployment

### Step 4: Access Your Live Form! 🎉

Your form will be live at:
```
https://[your-github-username].github.io/enrollment-form/
```

**Example:** If your username is `lolowaystardemo`, your URL will be:
```
https://lolowaystardemo.github.io/enrollment-form/
```

GitHub will show you the URL on the Pages settings page once it's ready!

---

## Method 2: GitHub Desktop (Slightly More Technical)

### Step 1: Download GitHub Desktop
- Download from: https://desktop.github.com/
- Install and sign in with your GitHub account

### Step 2: Create Repository
1. Click **File → New Repository**
2. Name: `enrollment-form`
3. Local Path: Choose where to save it
4. Click **"Create Repository"**

### Step 3: Add Your Files
1. Copy all 5 files into the repository folder
2. GitHub Desktop will detect the changes
3. In the bottom left:
   - Summary: "Initial commit"
   - Description: "Add enrollment form files"
4. Click **"Commit to main"**

### Step 4: Publish to GitHub
1. Click **"Publish repository"** (top right)
2. Uncheck "Keep this code private"
3. Click **"Publish Repository"**

### Step 5: Enable GitHub Pages
1. Go to your repository on GitHub.com
2. Follow Step 3 from Method 1 above

---

## Method 3: Command Line (For Developers)

```bash
# Navigate to your enrollment-form folder
cd path/to/enrollment-form

# Initialize git
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit: Enrollment consultation form"

# Create repository on GitHub first, then:
git remote add origin https://github.com/[your-username]/enrollment-form.git
git branch -M main
git push -u origin main
```

Then enable GitHub Pages via Settings → Pages.

---

## Testing Your Form Before Deployment

Want to test locally first?

1. **Simple way:** Just double-click `index.html` - it will open in your browser
2. **Server way (optional):**
   ```bash
   # If you have Python installed:
   python -m http.server 8000
   # Then visit: http://localhost:8000
   ```

---

## Updating Your Form After Deployment

### To make changes:

**Web Method:**
1. Go to your repository on GitHub
2. Click on the file you want to edit (e.g., `index.html`)
3. Click the pencil icon (Edit)
4. Make your changes
5. Scroll down, add commit message
6. Click "Commit changes"
7. Wait 1-2 minutes - your site will auto-update!

**GitHub Desktop Method:**
1. Edit the files on your computer
2. GitHub Desktop shows the changes
3. Commit and push
4. Site auto-updates!

---

## Customizing Your Form

### Change Colors
Edit `styles.css`:
- Line 61: Header background color
- Line 143: Submit button color
- Line 77-78: Section headers

### Change Company Name
Edit `index.html`:
- Line 15: Update WAYSTAR text in logo
- Update form title if needed

### Add/Remove Fields
1. Edit `index.html` to modify the form structure
2. Edit `script.js` to include new fields in PDF generation

---

## Troubleshooting

### ❌ GitHub Pages shows 404
- **Wait 2-3 minutes** after enabling Pages
- Check repository is **Public** (not Private)
- Verify **main branch** is selected in Pages settings
- Clear browser cache and try again

### ❌ PDF won't generate
- Check browser console (F12) for errors
- Disable ad blockers
- Try a different browser (Chrome recommended)
- Ensure internet connection (jsPDF loads from CDN)

### ❌ Form looks broken
- Make sure all 5 files uploaded correctly
- Check that file names are exact (case-sensitive)
- Clear browser cache

### ❌ Can't upload files
- Repository must be **Public** for free GitHub Pages
- Files must be under 100MB each (these are tiny, so no issue)
- Check you're logged into GitHub

---

## Sharing Your Form

Once deployed, share the link with your team:
```
https://[your-username].github.io/enrollment-form/
```

You can also:
- Add it to your company intranet
- Bookmark it in browsers
- Share via email/Slack
- Create a QR code for mobile access

---

## What Happens When Someone Fills It Out?

1. User visits your GitHub Pages URL
2. Fills out the form in their browser
3. Clicks "Generate PDF"
4. A PDF downloads to their computer
5. They can email/upload that PDF to your team

**Note:** No data is stored on GitHub or sent anywhere. Everything happens in the user's browser!

---

## Advanced: Custom Domain (Optional)

Want to use a custom domain like `enrollment.waystar.com`?

1. Buy a domain (or use existing)
2. In GitHub repository Settings → Pages
3. Add custom domain
4. Update DNS records with your domain provider
5. See: https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site

---

## Need Help?

- **GitHub Pages Docs:** https://docs.github.com/en/pages
- **jsPDF Docs:** https://github.com/parallax/jsPDF
- **GitHub Support:** https://support.github.com/

---

## Success Checklist

✅ Created GitHub repository  
✅ Uploaded all 5 files  
✅ Enabled GitHub Pages  
✅ Waited 2-3 minutes  
✅ Tested the live URL  
✅ Form loads correctly  
✅ PDF generates successfully  
✅ Shared with team  

---

**You're all set!** 🎉

Your enrollment consultation form is now live and accessible to anyone with the link.
